# GTA Classic Trilogy — RU / 60 FPS

Три отдельные папки с установщиками. Запускайте Install.cmd внутри нужной игры.

GTA III      → GTA_III/Install.cmd
GTA VC       → GTA_VICE_CITY/Install.cmd
GTA SA       → GTA_SAN_ANDREAS/Install.cmd

Русская озвучка и тексты — в RU-LOCALIZATION.txt внутри каждой папки.
